from flask import Flask, render_template

app = Flask(__name__)


@app.route('/<title>')
@app.route('/index/<title>')
def index(title):
    return render_template('base.html', title=title)


@app.route('/training/<prof>')
def training(prof):
    return render_template('base1.html', prof=prof.lower())


@app.route('/list_prof/<list>')
def prov(list):
    prof = ['Программист', 'Астронавт', 'Врач', 'Биолог', 'Инженер', 'Космонавт']
    return render_template('list_pr.html', list=list, prof=prof)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')